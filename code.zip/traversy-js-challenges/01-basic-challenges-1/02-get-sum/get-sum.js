function getSum() {}

module.exports = getSum;
