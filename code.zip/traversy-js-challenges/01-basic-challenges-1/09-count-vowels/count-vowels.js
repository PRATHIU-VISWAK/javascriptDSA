function countVowels() {}

module.exports = countVowels;
