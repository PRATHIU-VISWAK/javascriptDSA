function calculator() {}

module.exports = calculator;
