function helloWorld() {
  // Return the string 'Hello World!'
  return 'Hello World!';
}

module.exports = helloWorld;
