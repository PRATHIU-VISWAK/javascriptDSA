class Node {}

function recDepthFirstTraversal() {}

module.exports = {
  Node,
  recDepthFirstTraversal,
};
