function arrayIntersection() {}

module.exports = arrayIntersection;
