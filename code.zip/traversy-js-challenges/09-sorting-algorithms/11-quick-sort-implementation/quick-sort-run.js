const quickSort = require('./quick-sort');

const array = [20, 13, 3, 2, 10, 12, 1, 5, 6];

const result = quickSort(array);

console.log(result);
