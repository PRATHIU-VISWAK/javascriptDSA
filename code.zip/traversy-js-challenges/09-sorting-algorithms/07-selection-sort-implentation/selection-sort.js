function selectionSort() {}

module.exports = selectionSort;
