function flattenArray() {}

module.exports = flattenArray;
