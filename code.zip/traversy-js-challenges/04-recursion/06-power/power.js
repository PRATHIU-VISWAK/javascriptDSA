function power() {}

module.exports = power;
