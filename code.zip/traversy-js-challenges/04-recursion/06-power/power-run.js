const power = require('./power');

const result = power(2, 4);

console.log(result);
