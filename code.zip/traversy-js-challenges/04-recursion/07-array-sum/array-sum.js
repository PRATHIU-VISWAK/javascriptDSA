function arraySum() {}

module.exports = arraySum;
