const sumUpTo = require('./sum-up-to');

const result = sumUpTo(6);

console.log(result);
