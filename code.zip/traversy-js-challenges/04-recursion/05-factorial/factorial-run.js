const factorial = require('./factorial');

const result = factorial(5);

console.log(result);
