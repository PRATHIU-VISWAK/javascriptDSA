function calculateTotalSalesWithTax() {}

module.exports = calculateTotalSalesWithTax;
