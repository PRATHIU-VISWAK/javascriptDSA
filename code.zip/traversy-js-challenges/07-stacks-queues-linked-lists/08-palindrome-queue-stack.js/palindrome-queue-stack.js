const Queue = require('./queue');
const Stack = require('./stack');

function isPalindromeQueueStack() {}

module.exports = isPalindromeQueueStack;
