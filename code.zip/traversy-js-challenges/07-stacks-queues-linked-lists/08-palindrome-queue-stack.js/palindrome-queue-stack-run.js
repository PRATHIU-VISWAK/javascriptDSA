const isPalindromeQueueStack = require('./palindrome-queue-stack');

const result1 = isPalindromeQueueStack('A man, a plan, a canal: Panama');
const result2 = isPalindromeQueueStack('Hello');

console.log(result1, result2);
