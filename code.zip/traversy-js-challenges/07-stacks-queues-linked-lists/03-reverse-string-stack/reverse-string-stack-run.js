const reverseStringStack = require('./reverse-string-stack');

const result = reverseStringStack('Hello World!');

console.log(result);
