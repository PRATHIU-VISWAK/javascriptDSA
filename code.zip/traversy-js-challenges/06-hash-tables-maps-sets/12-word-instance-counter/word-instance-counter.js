const HashTable = require('./HashTable');

function wordInstanceCounter() {}

module.exports = wordInstanceCounter;
